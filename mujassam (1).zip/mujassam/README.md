# Mujassam · مجسّم

Landing page for **Mujassam**: natural language → validated CAD in real millimetres → STEP / STL / GLB.

A small workshop robot, built in 3D with three.js, follows your cursor and acts out the pipeline as you scroll:

1. **Hero** – the robot at its workbench; type a part in the prompt box and the visor reads the mm values.
2. **The scale problem** – a 60 × 40 × 5 mm plate starts as a speck and grows to true size.
3. **How it works** – read the spec → recipe RAG → the fork (deterministic compiler / corrected QLoRA fallback) → validation gate → export.
4. **Live demo gallery** – bearing mount, sensor bracket and shaft collar on turntables, with x-ray and hover dimensions.
5. **Try it** – presets that the robot welds layer by layer.
6. **Honest results** – development-set envelope pass @ 1.
7. **What we tried** – rejected approaches.
8. **Footer CTA**.

## Run it

It is a single static file with no build step. Open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
```

three.js (r128) and Google Fonts load from CDNs.

## To do

- [ ] Add the one-line reason for each rejected approach in "What we tried".
- [ ] Point the footer links (sample STEP files, lab notebook, team) at real URLs.
- [ ] Replace the procedural gallery models with the pipeline's GLB outputs.
- [ ] Publish the held-out p11–p20 result once it has run.
